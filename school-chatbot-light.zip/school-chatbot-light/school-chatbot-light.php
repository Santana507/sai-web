<?php
/**
 * Plugin Name: School Chatbot Light
 * Description: Chatbot educativo con proveedores de IA y base de conocimiento en Google Drive.
 * Version: 3.0.1
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * License: GPL-2.0-or-later
 */
defined( 'ABSPATH' ) || exit;
define( 'SCL_VERSION', '3.0.1' );
define( 'SCL_FILE', __FILE__ );
define( 'SCL_DIR', plugin_dir_path( __FILE__ ) );
define( 'SCL_URL', plugin_dir_url( __FILE__ ) );
require_once SCL_DIR . 'includes/class-scl-crypto.php';
require_once SCL_DIR . 'includes/class-scl-ai.php';
require_once SCL_DIR . 'includes/class-scl-drive.php';
require_once SCL_DIR . 'includes/class-scl-knowledge.php';
require_once SCL_DIR . 'includes/class-scl-admin.php';
require_once SCL_DIR . 'includes/class-scl-chat.php';

function scl_defaults() { return array( 'ai_mode' => 'local', 'local_provider' => 'ollama', 'local_url' => 'http://127.0.0.1:11434', 'provider' => 'openai', 'model' => 'qwen3:1.7b', 'custom_model' => '', 'ollama_url' => 'http://127.0.0.1:11434', 'cloud_urls' => array(), 'temperature' => '0.2', 'max_tokens' => '250', 'official_info' => '', 'provider_keys' => array(), 'apps_script_url' => '', 'apps_script_secret' => '', 'drive_main_id' => '', 'drive_main_name' => 'Chatbot WordPress', 'official_folder_id' => '', 'official_folder_name' => 'Información Oficial', 'important_folder_id' => '', 'important_folder_name' => 'Documentos Importantes' ); }
function scl_options() { return wp_parse_args( get_option( 'scl_options', array() ), scl_defaults() ); }
function scl_update_options( $values ) { update_option( 'scl_options', wp_parse_args( $values, scl_options() ), false ); }
function scl_table( $name ) { global $wpdb; return $wpdb->prefix . 'scl_' . $name; }
function scl_activate() {
	global $wpdb; require_once ABSPATH . 'wp-admin/includes/upgrade.php'; $charset = $wpdb->get_charset_collate(); $documents = scl_table( 'documents' ); $chunks = scl_table( 'chunks' );
	dbDelta( "CREATE TABLE $documents (id bigint(20) unsigned NOT NULL AUTO_INCREMENT, drive_file_id varchar(191) NOT NULL, folder_id varchar(191) NOT NULL, name varchar(255) NOT NULL, mime_type varchar(191) NOT NULL, drive_url text NULL, is_public tinyint(1) NOT NULL DEFAULT 0, modified_time datetime NULL, checksum char(64) NOT NULL, extraction_status varchar(20) NOT NULL DEFAULT 'ready', extraction_error text NULL, extracted_text longtext NULL, synced_at datetime NOT NULL, PRIMARY KEY (id), UNIQUE KEY drive_file_id (drive_file_id), KEY folder_id (folder_id), KEY modified_time (modified_time)) $charset;" );
	dbDelta( "CREATE TABLE $chunks (id bigint(20) unsigned NOT NULL AUTO_INCREMENT, document_id bigint(20) unsigned NOT NULL, chunk_index int(10) unsigned NOT NULL, chunk_text longtext NOT NULL, text_hash char(64) NOT NULL, updated_at datetime NOT NULL, PRIMARY KEY (id), UNIQUE KEY document_chunk (document_id, chunk_index), KEY document_id (document_id), KEY text_hash (text_hash)) $charset;" );
	$options = get_option( 'scl_options', false );
	if ( false === $options ) {
		add_option( 'scl_options', scl_defaults(), '', false );
	} else {
		$options = wp_parse_args( $options, scl_defaults() );
		foreach ( array( 'google_client_id', 'google_client_secret', 'google_token', 'google_folder_id', 'google_folder_name', 'google_account_email' ) as $legacy ) unset( $options[ $legacy ] );
		update_option( 'scl_options', $options, false );
	}
	update_option( 'scl_db_version', SCL_VERSION, false );
}
register_activation_hook( __FILE__, 'scl_activate' );
function scl_maybe_upgrade() { if ( SCL_VERSION !== get_option( 'scl_db_version' ) ) scl_activate(); }
add_action( 'admin_init', 'scl_maybe_upgrade' );
function scl_boot() { new SCL_Admin(); new SCL_Chat(); }
add_action( 'plugins_loaded', 'scl_boot' );
function scl_assets() { if ( is_admin() ) return; wp_enqueue_style( 'scl', SCL_URL . 'assets/chat.css', array(), SCL_VERSION ); wp_enqueue_script( 'scl', SCL_URL . 'assets/chat.js', array(), SCL_VERSION, true ); wp_localize_script( 'scl', 'SCL', array( 'ajax' => admin_url( 'admin-ajax.php' ), 'nonce' => wp_create_nonce( 'scl_chat' ) ) ); }
add_action( 'wp_enqueue_scripts', 'scl_assets' );
function scl_render_chat() { if ( is_admin() ) return; ?>
<button class="scl-toggle" type="button" aria-label="Abrir chat" aria-expanded="false">💬</button><section class="scl-box" hidden aria-label="Chat institucional"><header><strong>Asistente institucional</strong><button class="scl-close" type="button" aria-label="Cerrar">×</button></header><div class="scl-messages" aria-live="polite"></div><form class="scl-form"><textarea maxlength="800" rows="2" placeholder="Escribe tu pregunta…" required></textarea><button>Enviar</button></form></section>
<?php }
add_action( 'wp_footer', 'scl_render_chat' );
