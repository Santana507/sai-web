<?php
defined( 'ABSPATH' ) || exit;

class SCL_Admin {
	public function __construct() {
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_post_scl_save', array( $this, 'save' ) );
		add_action( 'admin_post_scl_test', array( $this, 'test_ai' ) );
		add_action( 'admin_post_scl_apps_test', array( $this, 'test_apps_script' ) );
		add_action( 'admin_post_scl_create_structure', array( $this, 'create_structure' ) );
		add_action( 'admin_post_scl_sync', array( $this, 'sync' ) );
	}

	public function menu() { add_options_page( 'School Chatbot Light', 'School Chatbot Light', 'manage_options', 'school-chatbot-light', array( $this, 'page' ) ); }
	private function guard( $action ) { if ( ! current_user_can( 'manage_options' ) ) wp_die( 'No autorizado.' ); check_admin_referer( $action ); }
	private function back( $message, $type = 'success' ) { set_transient( 'scl_notice_' . get_current_user_id(), array( $type, $message ), MINUTE_IN_SECONDS ); wp_safe_redirect( admin_url( 'options-general.php?page=school-chatbot-light' ) ); exit; }

	public function save() {
		$this->guard( 'scl_save' );
		$old = scl_options();
		$mode = 'cloud' === ( $_POST['ai_mode'] ?? '' ) ? 'cloud' : 'local';
		$cloud = array( 'openai', 'gemini', 'qwen', 'google_gemma', 'deepseek', 'anthropic', 'other' );
		$provider = in_array( $_POST['provider'] ?? '', $cloud, true ) ? $_POST['provider'] : 'openai';
		$local = in_array( $_POST['local_provider'] ?? '', array( 'ollama', 'local_compatible' ), true ) ? $_POST['local_provider'] : 'ollama';
		$keys = $old['provider_keys'];
		foreach ( $cloud as $p ) {
			$key = trim( wp_unslash( $_POST['api_key_' . $p] ?? '' ) );
			if ( '' !== $key ) {
				$encrypted = SCL_Crypto::encrypt( $key );
				if ( is_wp_error( $encrypted ) ) $this->back( $encrypted->get_error_message(), 'error' );
				$keys[ $p ] = $encrypted;
			}
		}
		$app_secret = trim( wp_unslash( $_POST['apps_script_secret'] ?? '' ) );
		$stored_secret = $old['apps_script_secret'];
		if ( '' !== $app_secret ) {
			$stored_secret = SCL_Crypto::encrypt( $app_secret );
			if ( is_wp_error( $stored_secret ) ) $this->back( $stored_secret->get_error_message(), 'error' );
		}
		$urls = $old['cloud_urls'];
		foreach ( array( 'qwen', 'other' ) as $p ) if ( isset( $_POST['cloud_url_' . $p] ) ) $urls[ $p ] = esc_url_raw( wp_unslash( $_POST['cloud_url_' . $p] ) );
		scl_update_options( array(
			'ai_mode' => $mode, 'local_provider' => $local, 'local_url' => esc_url_raw( wp_unslash( $_POST['local_url'] ?? $old['local_url'] ) ),
			'provider' => $provider, 'model' => sanitize_text_field( wp_unslash( $_POST['model'] ?? '' ) ),
			'custom_model' => sanitize_text_field( wp_unslash( $_POST['custom_model'] ?? '' ) ),
			'ollama_url' => esc_url_raw( wp_unslash( $_POST['local_url'] ?? $old['ollama_url'] ) ), 'cloud_urls' => $urls,
			'temperature' => (string) max( 0, min( 2, (float) ( $_POST['temperature'] ?? 0.2 ) ) ),
			'max_tokens' => (string) max( 32, min( 4000, absint( $_POST['max_tokens'] ?? 250 ) ) ),
			'official_info' => sanitize_textarea_field( wp_unslash( $_POST['official_info'] ?? '' ) ), 'provider_keys' => $keys,
			'apps_script_url' => esc_url_raw( wp_unslash( $_POST['apps_script_url'] ?? '' ) ), 'apps_script_secret' => $stored_secret,
			'drive_main_name' => sanitize_text_field( wp_unslash( $_POST['drive_main_name'] ?? 'Chatbot WordPress' ) ),
			'official_folder_name' => sanitize_text_field( wp_unslash( $_POST['official_folder_name'] ?? 'Información Oficial' ) ),
			'important_folder_name' => sanitize_text_field( wp_unslash( $_POST['important_folder_name'] ?? 'Documentos Importantes' ) ),
		) );
		$this->back( 'Configuración guardada.' );
	}

	public function test_ai() {
		$this->guard( 'scl_test' ); $o = scl_options();
		$r = SCL_AI::generate( $o, 'Responde solo con la palabra listo.', array( array( 'role' => 'user', 'content' => 'Prueba de conexión.' ) ) );
		$provider = 'local' === $o['ai_mode'] ? $o['local_provider'] : $o['provider'];
		$this->back( is_wp_error( $r ) ? $r->get_error_message() : 'Conexión correcta con ' . ucfirst( str_replace( '_', ' ', $provider ) ) . '.', is_wp_error( $r ) ? 'error' : 'success' );
	}

	public function test_apps_script() {
		$this->guard( 'scl_apps_test' ); $r = SCL_Drive::test();
		$this->back( is_wp_error( $r ) ? $r->get_error_message() : 'Google Apps Script respondió correctamente.', is_wp_error( $r ) ? 'error' : 'success' );
	}

	public function create_structure() {
		$this->guard( 'scl_create_structure' );
		$names = array(
			'main' => sanitize_text_field( wp_unslash( $_POST['drive_main_name'] ?? 'Chatbot WordPress' ) ),
			'official' => sanitize_text_field( wp_unslash( $_POST['official_folder_name'] ?? 'Información Oficial' ) ),
			'important' => sanitize_text_field( wp_unslash( $_POST['important_folder_name'] ?? 'Documentos Importantes' ) ),
		);
		$r = SCL_Drive::create_structure( $names );
		if ( is_wp_error( $r ) ) $this->back( $r->get_error_message(), 'error' );
		scl_update_options( array(
			'drive_main_name' => $names['main'], 'official_folder_name' => $names['official'], 'important_folder_name' => $names['important'],
			'drive_main_id' => sanitize_text_field( $r['main_folder_id'] ?? '' ),
			'official_folder_id' => sanitize_text_field( $r['official_folder_id'] ?? '' ),
			'important_folder_id' => sanitize_text_field( $r['important_folder_id'] ?? '' ),
		) );
		$this->back( 'Estructura de carpetas lista.' );
	}

	public function sync() {
		$this->guard( 'scl_sync' ); $r = SCL_Knowledge::sync();
		$this->back( is_wp_error( $r ) ? $r->get_error_message() : 'Sincronización completada: ' . $r . ' documentos oficiales detectados.', is_wp_error( $r ) ? 'error' : 'success' );
	}

	public function page() {
		if ( ! current_user_can( 'manage_options' ) ) return;
		$o = scl_options(); $models = SCL_AI::models();
		$cloud = array( 'openai', 'gemini', 'qwen', 'google_gemma', 'deepseek', 'anthropic', 'other' );
		$labels = array( 'openai' => 'OpenAI', 'gemini' => 'Gemini', 'qwen' => 'Qwen', 'google_gemma' => 'Google / Gemma', 'deepseek' => 'DeepSeek', 'anthropic' => 'Claude', 'other' => 'Otros / CUSTOM' );
		$active_provider = 'local' === $o['ai_mode'] ? $o['local_provider'] : $o['provider'];
		$notice = get_transient( 'scl_notice_' . get_current_user_id() ); delete_transient( 'scl_notice_' . get_current_user_id() );
		?>
		<div class="wrap scl-admin"><h1>School Chatbot Light</h1>
		<?php if ( $notice ) : ?><div class="notice notice-<?php echo esc_attr( $notice[0] ); ?>"><p><?php echo esc_html( $notice[1] ); ?></p></div><?php endif; ?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="scl_save"><?php wp_nonce_field( 'scl_save' ); ?>
			<div class="scl-card"><h2>Modo de IA</h2><table class="form-table">
				<tr><th>Modo</th><td><select name="ai_mode" id="scl-mode"><option value="local" <?php selected( $o['ai_mode'], 'local' ); ?>>LOCAL</option><option value="cloud" <?php selected( $o['ai_mode'], 'cloud' ); ?>>NUBE</option></select><p class="description">Local usa un servidor en tu red; Nube usa un proveedor externo.</p></td></tr>
				<tr class="scl-local"><th>Proveedor local</th><td><select name="local_provider" id="scl-local-provider"><option value="ollama" <?php selected( $o['local_provider'], 'ollama' ); ?>>Ollama</option><option value="local_compatible" <?php selected( $o['local_provider'], 'local_compatible' ); ?>>Endpoint local compatible</option></select></td></tr>
				<tr class="scl-local"><th>Servidor local</th><td><input class="regular-text" name="local_url" value="<?php echo esc_attr( $o['local_url'] ); ?>"><p class="description">Para Ollama normalmente: http://127.0.0.1:11434</p></td></tr>
				<tr class="scl-cloud"><th>Proveedor de IA</th><td><select name="provider" id="scl-provider"><?php foreach ( $cloud as $id ) : ?><option value="<?php echo esc_attr( $id ); ?>" <?php selected( $o['provider'], $id ); ?>><?php echo esc_html( $labels[ $id ] ); ?></option><?php endforeach; ?></select></td></tr>
				<tr><th>Modelo</th><td><select name="model" id="scl-model"><?php foreach ( $models[ $active_provider ] as $id => $name ) : ?><option value="<?php echo esc_attr( $id ); ?>" <?php selected( $o['model'], $id ); ?>><?php echo esc_html( $name ); ?></option><?php endforeach; ?></select></td></tr>
				<tr><th>Modelo personalizado</th><td><input class="regular-text" name="custom_model" value="<?php echo esc_attr( $o['custom_model'] ); ?>"><p class="description">Solo se usa al elegir CUSTOM.</p></td></tr>
				<?php foreach ( $cloud as $id ) : ?><tr class="scl-cloud scl-key" data-provider="<?php echo esc_attr( $id ); ?>"><th>API Key <?php echo esc_html( $labels[ $id ] ); ?></th><td><input type="password" class="regular-text" name="api_key_<?php echo esc_attr( $id ); ?>" placeholder="<?php echo ! empty( $o['provider_keys'][ $id ] ) ? 'Clave guardada — deja vacío para conservar' : ''; ?>"></td></tr><?php endforeach; ?>
				<tr class="scl-cloud scl-cloud-url" data-provider="qwen"><th>URL compatible de Qwen</th><td><input class="large-text" name="cloud_url_qwen" value="<?php echo esc_attr( $o['cloud_urls']['qwen'] ?? '' ); ?>" placeholder="https://..."></td></tr>
				<tr class="scl-cloud scl-cloud-url" data-provider="other"><th>URL API externa</th><td><input class="large-text" name="cloud_url_other" value="<?php echo esc_attr( $o['cloud_urls']['other'] ?? '' ); ?>" placeholder="https://api.ejemplo.com/v1"></td></tr>
				<tr><th>Temperatura</th><td><input type="number" name="temperature" min="0" max="2" step="0.1" value="<?php echo esc_attr( $o['temperature'] ); ?>"></td></tr>
				<tr><th>Máximo de tokens</th><td><input type="number" name="max_tokens" min="32" max="4000" value="<?php echo esc_attr( $o['max_tokens'] ); ?>"></td></tr>
			</table></div>
			<div class="scl-card"><h2>Google Drive mediante Apps Script</h2><table class="form-table">
				<tr><th>Web App URL</th><td><input class="large-text" name="apps_script_url" value="<?php echo esc_attr( $o['apps_script_url'] ); ?>" placeholder="https://script.google.com/macros/s/.../exec"><p class="description">URL /exec del Web App; no se usa Google Cloud Console en WordPress.</p></td></tr>
				<tr><th>Secreto de comunicación</th><td><input type="password" class="regular-text" name="apps_script_secret" placeholder="<?php echo $o['apps_script_secret'] ? 'Secreto guardado — deja vacío para conservar' : ''; ?>"><p class="description">Se cifra en WordPress y nunca se expone al chat público.</p></td></tr>
				<tr><th>Carpeta principal</th><td><input class="regular-text" name="drive_main_name" value="<?php echo esc_attr( $o['drive_main_name'] ); ?>"></td></tr>
				<tr><th>Información Oficial</th><td><input class="regular-text" name="official_folder_name" value="<?php echo esc_attr( $o['official_folder_name'] ); ?>"></td></tr>
				<tr><th>Documentos Importantes</th><td><input class="regular-text" name="important_folder_name" value="<?php echo esc_attr( $o['important_folder_name'] ); ?>"></td></tr>
			</table></div>
			<div class="scl-card"><h2>Información complementaria</h2><p>Es secundaria frente a los documentos oficiales sincronizados.</p><textarea class="large-text" rows="5" name="official_info"><?php echo esc_textarea( $o['official_info'] ); ?></textarea></div>
			<?php submit_button( 'Guardar configuración' ); ?>
		</form>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="scl_test"><?php wp_nonce_field( 'scl_test' ); submit_button( 'Probar conexión de IA', 'secondary', 'submit', false ); ?></form>
		<div class="scl-card"><h2>Operaciones de Google Drive</h2><p>Estado: <strong><?php echo SCL_Drive::connected() ? 'Configuración guardada' : 'Falta URL o secreto'; ?></strong></p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="scl_apps_test"><?php wp_nonce_field( 'scl_apps_test' ); submit_button( 'Probar conexión con Apps Script', 'secondary', 'submit', false ); ?></form>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="scl_create_structure"><?php wp_nonce_field( 'scl_create_structure' ); ?><input type="hidden" name="drive_main_name" value="<?php echo esc_attr( $o['drive_main_name'] ); ?>"><input type="hidden" name="official_folder_name" value="<?php echo esc_attr( $o['official_folder_name'] ); ?>"><input type="hidden" name="important_folder_name" value="<?php echo esc_attr( $o['important_folder_name'] ); ?>"><?php submit_button( 'Crear estructura de carpetas', 'secondary', 'submit', false ); ?></form>
			<p><small>Principal: <?php echo esc_html( $o['drive_main_id'] ?: 'sin crear' ); ?><br>Oficial: <?php echo esc_html( $o['official_folder_id'] ?: 'sin crear' ); ?><br>Importantes: <?php echo esc_html( $o['important_folder_id'] ?: 'sin crear' ); ?></small></p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="scl_sync"><?php wp_nonce_field( 'scl_sync' ); submit_button( 'Sincronizar Google Drive', 'primary', 'submit', false ); ?></form>
		</div></div>
		<style>.scl-admin{max-width:1000px}.scl-card{background:#fff;border:1px solid #d8e1e6;border-radius:12px;margin:16px 0;padding:12px 24px 20px;box-shadow:0 2px 8px #0000000d}.scl-card h2{color:#0e7490}.scl-card form{margin:12px 0}.scl-admin .form-table th{width:210px}</style>
		<script>document.addEventListener('DOMContentLoaded',()=>{const mode=document.querySelector('#scl-mode'),local=document.querySelector('#scl-local-provider'),cloud=document.querySelector('#scl-provider'),model=document.querySelector('#scl-model'),lists=<?php echo wp_json_encode( $models ); ?>,saved=<?php echo wp_json_encode( $o['model'] ); ?>;let initial=true;function active(){return mode.value==='local'?local.value:cloud.value}function rows(selector,show){document.querySelectorAll(selector).forEach(row=>row.style.display=show?'table-row':'none')}function update(){const isLocal=mode.value==='local',provider=active(),keep=initial?saved:model.value;initial=false;rows('.scl-local',isLocal);rows('.scl-cloud',!isLocal);model.innerHTML='';Object.entries(lists[provider]||{}).forEach(([id,name])=>model.add(new Option(name,id,id===keep,id===keep)));if(!model.value&&model.options.length)model.selectedIndex=0;document.querySelectorAll('.scl-key').forEach(row=>row.style.display=!isLocal&&row.dataset.provider===provider?'table-row':'none');document.querySelectorAll('.scl-cloud-url').forEach(row=>row.style.display=!isLocal&&row.dataset.provider===provider?'table-row':'none')}mode.addEventListener('change',update);local.addEventListener('change',update);cloud.addEventListener('change',update);update()})</script>
		<?php
	}
}
