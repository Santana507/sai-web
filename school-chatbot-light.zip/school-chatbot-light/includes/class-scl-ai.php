<?php
defined( 'ABSPATH' ) || exit;
class SCL_AI {
	public static function models() { return array(
		'ollama' => array( 'qwen3:1.7b' => 'Qwen3 1.7B', 'qwen3:14b' => 'Qwen3 14B', 'custom' => 'CUSTOM / modelo personalizado' ),
		'local_compatible' => array( 'custom' => 'CUSTOM / modelo personalizado' ),
		'openai' => array( 'gpt-5.6' => 'GPT-5.6', 'gpt-5.6-terra' => 'GPT-5.6 Terra', 'gpt-5.6-luna' => 'GPT-5.6 Luna', 'custom' => 'CUSTOM / modelo personalizado' ),
		'gemini' => array( 'gemini-2.5-flash' => 'Gemini 2.5 Flash', 'gemini-2.5-flash-lite' => 'Gemini 2.5 Flash-Lite', 'gemini-2.5-pro' => 'Gemini 2.5 Pro', 'custom' => 'CUSTOM / modelo personalizado' ),
		'anthropic' => array( 'claude-sonnet-5' => 'Claude Sonnet 5', 'claude-haiku-4-5-20251001' => 'Claude Haiku 4.5', 'claude-opus-5' => 'Claude Opus 5', 'custom' => 'CUSTOM / modelo personalizado' ),
		'qwen' => array( 'qwen-plus' => 'Qwen Plus', 'qwen3.8-max' => 'Qwen 3.8 Max', 'custom' => 'CUSTOM / modelo personalizado' ),
		'deepseek' => array( 'deepseek-flash' => 'DeepSeek Flash', 'custom' => 'CUSTOM / modelo personalizado' ),
		'google_gemma' => array( 'gemma-4-26b-a4b-it' => 'Gemma 4 26B MoE IT', 'gemma-4-31b-it' => 'Gemma 4 31B IT', 'custom' => 'CUSTOM / modelo personalizado' ),
		'other' => array( 'custom' => 'CUSTOM / modelo personalizado' ),
	); }
	public static function model( $o ) { return 'custom' === $o['model'] ? $o['custom_model'] : $o['model']; }
	private static function key( $o, $provider ) { $stored = $o['provider_keys'][ $provider ] ?? ''; $key = SCL_Crypto::decrypt( $stored ); return is_wp_error( $key ) ? $key : trim( $key ); }
	private static function transcript( $messages ) { $text = ''; foreach ( $messages as $message ) $text .= strtoupper( $message['role'] ) . ":\n" . $message['content'] . "\n\n"; return $text; }
	public static function generate( $o, $system, $messages ) {
		$provider = 'local' === ( $o['ai_mode'] ?? 'local' ) ? ( $o['local_provider'] ?? 'ollama' ) : $o['provider']; $model = self::model( $o ); if ( '' === $model ) return new WP_Error( 'scl_model', 'Selecciona o escribe un modelo.' );
		if ( 'ollama' === $provider ) return self::ollama( $o, $system, $messages, $model );
		if ( 'local_compatible' === $provider ) return self::compatible( $o['local_url'], '', $system, $messages, $model );
		$key = self::key( $o, $provider ); if ( is_wp_error( $key ) ) return $key; if ( '' === $key ) return new WP_Error( 'scl_key', 'Configura la API Key del proveedor seleccionado.' );
		if ( 'openai' === $provider ) return self::openai( $o, $system, $messages, $model, $key );
		if ( 'gemini' === $provider || 'google_gemma' === $provider ) return self::gemini( $o, $system, $messages, $model, $key );
		if ( 'anthropic' === $provider ) return self::anthropic( $o, $system, $messages, $model, $key );
		if ( 'deepseek' === $provider ) return self::compatible( 'https://api.deepseek.com', $key, $system, $messages, $model );
		if ( 'qwen' === $provider || 'other' === $provider ) return self::compatible( $o['cloud_urls'][ $provider ] ?? '', $key, $system, $messages, $model );
		return new WP_Error( 'scl_provider', 'Proveedor no compatible.' );
	}
	private static function request( $url, $headers, $body ) { $r = wp_remote_post( $url, array( 'timeout' => 90, 'headers' => $headers, 'body' => wp_json_encode( $body ) ) ); if ( is_wp_error( $r ) ) return $r; if ( 200 > wp_remote_retrieve_response_code( $r ) || 299 < wp_remote_retrieve_response_code( $r ) ) return new WP_Error( 'scl_api', 'El proveedor no aceptó la solicitud.', array( 'status' => wp_remote_retrieve_response_code( $r ) ) ); return json_decode( wp_remote_retrieve_body( $r ), true ); }
	private static function ollama( $o, $system, $messages, $model ) { $r = self::request( untrailingslashit( $o['local_url'] ?? $o['ollama_url'] ) . '/api/chat', array( 'Content-Type' => 'application/json' ), array( 'model' => $model, 'messages' => array_merge( array( array( 'role' => 'system', 'content' => $system ) ), $messages ), 'stream' => false, 'think' => false, 'options' => array( 'temperature' => (float) $o['temperature'], 'num_predict' => (int) $o['max_tokens'] ) ) ); return is_wp_error( $r ) ? $r : trim( $r['message']['content'] ?? '' ); }
	private static function compatible( $base, $key, $system, $messages, $model ) { if ( '' === trim( $base ) ) return new WP_Error( 'scl_endpoint', 'Configura la URL compatible del proveedor.' ); $url = untrailingslashit( $base ); if ( ! preg_match( '#/chat/completions$#', $url ) ) $url .= '/chat/completions'; $headers = array( 'Content-Type' => 'application/json' ); if ( '' !== $key ) $headers['Authorization'] = 'Bearer ' . $key; $r = self::request( $url, $headers, array( 'model' => $model, 'messages' => array_merge( array( array( 'role' => 'system', 'content' => $system ) ), $messages ), 'temperature' => (float) scl_options()['temperature'], 'max_tokens' => (int) scl_options()['max_tokens'], 'stream' => false ) ); return is_wp_error( $r ) ? $r : trim( $r['choices'][0]['message']['content'] ?? '' ); }
	private static function openai( $o, $system, $messages, $model, $key ) { $r = self::request( 'https://api.openai.com/v1/responses', array( 'Content-Type' => 'application/json', 'Authorization' => 'Bearer ' . $key ), array( 'model' => $model, 'instructions' => $system, 'input' => self::transcript( $messages ), 'temperature' => (float) $o['temperature'], 'max_output_tokens' => (int) $o['max_tokens'] ) ); if ( is_wp_error( $r ) ) return $r; if ( ! empty( $r['output_text'] ) ) return trim( $r['output_text'] ); foreach ( $r['output'] ?? array() as $item ) foreach ( $item['content'] ?? array() as $part ) if ( isset( $part['text'] ) ) return trim( $part['text'] ); return new WP_Error( 'scl_empty', 'OpenAI no devolvió texto.' ); }
	private static function gemini( $o, $system, $messages, $model, $key ) { $contents = array(); foreach ( $messages as $m ) $contents[] = array( 'role' => 'assistant' === $m['role'] ? 'model' : 'user', 'parts' => array( array( 'text' => $m['content'] ) ) ); $r = self::request( 'https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode( $model ) . ':generateContent?key=' . rawurlencode( $key ), array( 'Content-Type' => 'application/json' ), array( 'systemInstruction' => array( 'parts' => array( array( 'text' => $system ) ) ), 'contents' => $contents, 'generationConfig' => array( 'temperature' => (float) $o['temperature'], 'maxOutputTokens' => (int) $o['max_tokens'] ) ) ); return is_wp_error( $r ) ? $r : trim( $r['candidates'][0]['content']['parts'][0]['text'] ?? '' ); }
	private static function anthropic( $o, $system, $messages, $model, $key ) { $body = array( 'model' => $model, 'max_tokens' => (int) $o['max_tokens'], 'system' => $system, 'messages' => $messages ); if ( 0 === strpos( $model, 'claude-3' ) || false !== strpos( $model, 'haiku-4-5' ) ) $body['temperature'] = (float) $o['temperature']; $r = self::request( 'https://api.anthropic.com/v1/messages', array( 'Content-Type' => 'application/json', 'x-api-key' => $key, 'anthropic-version' => '2023-06-01' ), $body ); return is_wp_error( $r ) ? $r : trim( $r['content'][0]['text'] ?? '' ); }
}
