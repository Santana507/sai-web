<?php
defined( 'ABSPATH' ) || exit;
class SCL_Knowledge {
	public static function sync() {
		$o = scl_options(); if ( empty( $o['official_folder_id'] ) ) return new WP_Error( 'scl_folder', 'Crea primero la estructura de carpetas en Google Apps Script.' ); $listing = SCL_Drive::files( $o['official_folder_id'] ); if ( is_wp_error( $listing ) ) return $listing; global $wpdb; $docs = scl_table( 'documents' ); $seen = array();
		foreach ( $listing['files'] ?? array() as $file ) { $seen[] = $file['id']; self::sync_file( $file, $o['official_folder_id'] ); }
		$existing = $wpdb->get_results( $wpdb->prepare( "SELECT id,drive_file_id FROM $docs WHERE folder_id=%s", $o['official_folder_id'] ) ); foreach ( $existing as $old ) if ( ! in_array( $old->drive_file_id, $seen, true ) ) { $wpdb->delete( scl_table( 'chunks' ), array( 'document_id' => $old->id ), array( '%d' ) ); $wpdb->delete( $docs, array( 'id' => $old->id ), array( '%d' ) ); }
		return count( $seen );
	}
	private static function sync_file( $file, $folder ) {
		global $wpdb; $docs = scl_table( 'documents' ); $old = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $docs WHERE drive_file_id=%s", $file['id'] ) ); $stamp = gmdate( 'Y-m-d H:i:s', strtotime( $file['modifiedTime'] ?? 'now' ) ); if ( $old && $old->modified_time === $stamp ) return;
		$text = self::extract( $file ); $data = array( 'drive_file_id' => $file['id'], 'folder_id' => $folder, 'name' => sanitize_text_field( $file['name'] ), 'mime_type' => $file['mimeType'], 'drive_url' => esc_url_raw( $file['webViewLink'] ?? '' ), 'is_public' => SCL_Drive::public( $file ) ? 1 : 0, 'modified_time' => $stamp, 'checksum' => hash( 'sha256', is_wp_error( $text ) ? '' : $text ), 'extraction_status' => is_wp_error( $text ) ? 'error' : 'ready', 'extraction_error' => is_wp_error( $text ) ? $text->get_error_message() : '', 'extracted_text' => is_wp_error( $text ) ? '' : $text, 'synced_at' => current_time( 'mysql', true ) );
		if ( $old ) { $wpdb->update( $docs, $data, array( 'id' => $old->id ) ); $id = $old->id; } else { $wpdb->insert( $docs, $data ); $id = $wpdb->insert_id; } if ( ! is_wp_error( $text ) ) self::index( $id, $text );
	}
	private static function extract( $file ) { $type = $file['mimeType']; if ( in_array( $type, array( 'text/plain', 'text/csv', 'application/vnd.google-apps.document' ), true ) ) { $text = SCL_Drive::content( $file ); return is_wp_error( $text ) ? $text : wp_strip_all_tags( $text ); } $binary = SCL_Drive::content( $file ); if ( is_wp_error( $binary ) ) return $binary; if ( 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' === $type ) return self::docx( $binary ); if ( 'application/pdf' === $type ) return self::pdf( $binary ); return new WP_Error( 'scl_type', 'Formato no compatible: ' . $type ); }
	private static function docx( $binary ) { if ( ! class_exists( 'ZipArchive' ) ) return new WP_Error( 'scl_docx', 'El servidor requiere la extensión PHP ZipArchive para leer DOCX.' ); $file = wp_tempnam( 'scl-docx' ); file_put_contents( $file, $binary ); $zip = new ZipArchive(); if ( true !== $zip->open( $file ) ) return new WP_Error( 'scl_docx', 'No se pudo abrir el archivo DOCX.' ); $xml = $zip->getFromName( 'word/document.xml' ); $zip->close(); @unlink( $file ); return trim( wp_strip_all_tags( str_replace( '</w:p>', "\n", $xml ) ) ); }
	private static function pdf( $binary ) {
    if ( ! function_exists( 'shell_exec' ) ) {
        return new WP_Error(
            'scl_pdf',
            'El servidor no tiene shell_exec disponible.'
        );
    }

    $in  = wp_tempnam( 'scl-pdf' );
    $out = wp_tempnam( 'scl-text' );

    if ( ! $in || ! $out ) {
        return new WP_Error(
            'scl_pdf',
            'No se pudieron crear los archivos temporales.'
        );
    }

    if ( file_put_contents( $in, $binary ) === false ) {
        @unlink( $in );
        @unlink( $out );

        return new WP_Error(
            'scl_pdf',
            'No se pudo guardar temporalmente el PDF.'
        );
    }

    $bin = strtoupper( substr( PHP_OS, 0, 3 ) ) === 'WIN'
        ? 'C:\\Users\\Eduardo P\\Desktop\\Release-26.09.0-0\\poppler-26.09.0\\Library\\bin\\pdftotext.exe'
        : 'pdftotext';

    $command = escapeshellarg( $bin )
        . ' -enc UTF-8 '
        . escapeshellarg( $in )
        . ' '
        . escapeshellarg( $out )
        . ' 2>&1';

    $output = shell_exec( $command );

    $text = is_readable( $out ) ? file_get_contents( $out ) : '';

    @unlink( $in );
    @unlink( $out );

    if ( trim( $text ) === '' ) {
        $detail = trim( (string) $output );

        return new WP_Error(
            'scl_pdf',
            'Falló la extracción del PDF.'
                . ( $detail !== '' ? ' Detalle: ' . $detail : ' Poppler no generó texto.' )
        );
    }

    return trim( $text );
}
	private static function index( $id, $text ) { global $wpdb; $chunks = scl_table( 'chunks' ); $wpdb->delete( $chunks, array( 'document_id' => $id ), array( '%d' ) ); $text = preg_replace( '/\s+/u', ' ', trim( $text ) ); $size = 1200; $overlap = 200; for ( $i = 0, $n = 0; $i < mb_strlen( $text ); $i += $size - $overlap, $n++ ) { $piece = trim( mb_substr( $text, $i, $size ) ); if ( '' !== $piece ) $wpdb->insert( $chunks, array( 'document_id' => $id, 'chunk_index' => $n, 'chunk_text' => $piece, 'text_hash' => hash( 'sha256', $piece ), 'updated_at' => current_time( 'mysql', true ) ) ); } }
	public static function search( $question ) { global $wpdb; $chunks = scl_table( 'chunks' ); $docs = scl_table( 'documents' ); $terms = array_unique( array_filter( preg_split( '/[^\p{L}\p{N}]+/u', mb_strtolower( $question ) ), function( $term ) { return mb_strlen( $term ) > 3; } ) ); if ( ! $terms ) return array(); $rows = $wpdb->get_results( "SELECT c.chunk_text,d.name,d.drive_url,d.is_public FROM $chunks c INNER JOIN $docs d ON d.id=c.document_id WHERE d.extraction_status='ready'" ); foreach ( $rows as $row ) { $score = 0; $hay = mb_strtolower( $row->chunk_text ); foreach ( $terms as $term ) $score += substr_count( $hay, $term ); $row->score = $score; } usort( $rows, function( $a, $b ) { return $b->score <=> $a->score; } ); return array_slice( array_values( array_filter( $rows, function( $r ) { return $r->score > 0; } ) ), 0, 5 ); }
}
