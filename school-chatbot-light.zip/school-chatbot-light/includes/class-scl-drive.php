<?php
defined( 'ABSPATH' ) || exit;

/**
 * Cliente privado para el Web App de Google Apps Script.
 * WordPress no accede directamente a Google Drive mediante OAuth.
 */
class SCL_Drive {

    private static function options() {
        return scl_options();
    }

    private static function secret() {
        $options = self::options();

        $secret = SCL_Crypto::decrypt(
            $options['apps_script_secret'] ?? ''
        );

        return is_wp_error( $secret )
            ? $secret
            : trim( $secret );
    }

    public static function connected() {
        $options = self::options();

        return ! empty( $options['apps_script_url'] )
            && ! empty( $options['apps_script_secret'] );
    }

    public static function request( $operation, $payload = array() ) {
        $options = self::options();

        if ( empty( $options['apps_script_url'] ) ) {
            return new WP_Error(
                'scl_apps_script',
                'Guarda la URL del Web App de Google Apps Script.'
            );
        }

        $secret = self::secret();

        if ( is_wp_error( $secret ) ) {
            return $secret;
        }

        if ( '' === $secret ) {
            return new WP_Error(
                'scl_apps_script',
                'Guarda el secreto de comunicación de Google Apps Script.'
            );
        }

        $body = array_merge(
            array(
                'operation' => $operation,
                'token'     => $secret,
            ),
            $payload
        );

        /*
         * PASO 1:
         * Enviar el POST sin seguir automáticamente la redirección.
         */
        $response = wp_remote_post(
            esc_url_raw( $options['apps_script_url'] ),
            array(
                'timeout'     => 90,
                'redirection' => 0,
                'httpversion' => '1.1',
                'headers'     => array(
                    'Accept'       => 'application/json',
                    'Content-Type' => 'application/json; charset=utf-8',
                ),
                'body'        => wp_json_encode( $body ),
                'data_format' => 'body',
            )
        );

        if ( is_wp_error( $response ) ) {
            return new WP_Error(
                'scl_apps_script',
                'No fue posible contactar Google Apps Script: ' .
                $response->get_error_message()
            );
        }

        $code = wp_remote_retrieve_response_code( $response );

        /*
         * PASO 2:
         * Apps Script suele devolver un 302 hacia googleusercontent.com.
         * Si ocurre, solicitamos el destino mediante GET.
         */
        if ( in_array( $code, array( 301, 302, 303, 307, 308 ), true ) ) {
            $location = wp_remote_retrieve_header(
                $response,
                'location'
            );

            if ( ! is_string( $location ) || '' === trim( $location ) ) {
                return new WP_Error(
                    'scl_apps_script',
                    'Google devolvió una redirección sin URL de destino.'
                );
            }

            $location = trim( $location );

            if ( ! wp_http_validate_url( $location ) ) {
                return new WP_Error(
                    'scl_apps_script',
                    'Google devolvió una URL de redirección no válida.'
                );
            }

            $host = wp_parse_url( $location, PHP_URL_HOST );

            if (
                ! is_string( $host ) ||
                ! preg_match(
                    '/(^|\.)googleusercontent\.com$/i',
                    $host
                )
            ) {
                return new WP_Error(
                    'scl_apps_script',
                    'El destino de la redirección no pertenece a googleusercontent.com.'
                );
            }

            $response = wp_remote_get(
                $location,
                array(
                    'timeout'     => 90,
                    'redirection' => 3,
                    'headers'     => array(
                        'Accept' => 'application/json',
                    ),
                )
            );

            if ( is_wp_error( $response ) ) {
                return new WP_Error(
                    'scl_apps_script',
                    'No fue posible obtener la respuesta redirigida: ' .
                    $response->get_error_message()
                );
            }
        }

        /*
         * PASO 3:
         * Comprobar la respuesta final y procesar el JSON.
         */
        $code = wp_remote_retrieve_response_code( $response );
        $raw  = wp_remote_retrieve_body( $response );
        $data = json_decode( $raw, true );

        if ( 200 > $code || 299 < $code || ! is_array( $data ) ) {
            $detail = trim( wp_strip_all_tags( $raw ) );
            $detail = preg_replace( '/\s+/', ' ', $detail );

            return new WP_Error(
                'scl_apps_script',
                'Google Apps Script devolvió una respuesta no válida (HTTP ' .
                $code . ').' .
                (
                    $detail
                    ? ' Detalle: ' . mb_substr( $detail, 0, 300 )
                    : ''
                )
            );
        }

        if ( empty( $data['success'] ) ) {
            return new WP_Error(
                'scl_apps_script',
                sanitize_text_field(
                    $data['error'] ??
                    'La operación fue rechazada por Google Apps Script.'
                )
            );
        }

        return $data;
    }

    public static function test() {
        return self::request( 'test_connection' );
    }

    public static function create_structure( $names ) {
        return self::request(
            'create_structure',
            array(
                'names' => array(
                    'main' => sanitize_text_field(
                        $names['main'] ?? 'Chatbot WordPress'
                    ),
                    'official' => sanitize_text_field(
                        $names['official'] ?? 'Información Oficial'
                    ),
                    'important' => sanitize_text_field(
                        $names['important'] ?? 'Documentos Importantes'
                    ),
                ),
            )
        );
    }

    public static function files( $folder_id ) {
        $options = self::options();

        $operation = (
            $folder_id === ( $options['important_folder_id'] ?? '' )
        )
            ? 'list_important_documents'
            : 'list_official_documents';

        $result = self::request( $operation );

        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return array(
            'files' => $result['files'] ?? array(),
        );
    }

    public static function content( $file ) {
        $result = self::request(
            'get_document_content',
            array(
                'file_id' => sanitize_text_field(
                    $file['id'] ?? ''
                ),
            )
        );

        if ( is_wp_error( $result ) ) {
            return $result;
        }

        if ( 'base64' === ( $result['encoding'] ?? '' ) ) {
            $binary = base64_decode(
                $result['content'] ?? '',
                true
            );

            return false === $binary
                ? new WP_Error(
                    'scl_apps_script',
                    'Contenido binario inválido recibido desde Apps Script.'
                )
                : $binary;
        }

        return (string) ( $result['content'] ?? '' );
    }

    public static function public( $file ) {
        return ! empty( $file['isPublic'] );
    }

    public static function important_files() {
        $options = self::options();

        if ( empty( $options['important_folder_id'] ) ) {
            return array();
        }

        $listing = self::files(
            $options['important_folder_id']
        );

        return is_wp_error( $listing )
            ? $listing
            : ( $listing['files'] ?? array() );
    }
}