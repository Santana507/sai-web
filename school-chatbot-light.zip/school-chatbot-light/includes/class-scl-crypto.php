<?php
defined( 'ABSPATH' ) || exit;
class SCL_Crypto {
	public static function available() { return function_exists( 'openssl_encrypt' ) && function_exists( 'openssl_decrypt' ); }
	private static function key() { return hash( 'sha256', wp_salt( 'auth' ), true ); }
	public static function encrypt( $value ) {
		if ( '' === (string) $value ) return ''; if ( ! self::available() ) return new WP_Error( 'scl_crypto', 'OpenSSL no está disponible en este servidor.' );
		$iv = random_bytes( 16 ); $cipher = openssl_encrypt( $value, 'aes-256-cbc', self::key(), OPENSSL_RAW_DATA, $iv );
		return base64_encode( $iv . hash_hmac( 'sha256', $iv . $cipher, self::key(), true ) . $cipher );
	}
	public static function decrypt( $value ) {
		if ( '' === (string) $value ) return ''; if ( ! self::available() ) return new WP_Error( 'scl_crypto', 'OpenSSL no está disponible en este servidor.' );
		$raw = base64_decode( $value, true ); if ( false === $raw || strlen( $raw ) < 49 ) return new WP_Error( 'scl_crypto', 'Credencial cifrada no válida.' );
		$iv = substr( $raw, 0, 16 ); $mac = substr( $raw, 16, 32 ); $cipher = substr( $raw, 48 ); if ( ! hash_equals( $mac, hash_hmac( 'sha256', $iv . $cipher, self::key(), true ) ) ) return new WP_Error( 'scl_crypto', 'No se pudo validar la credencial.' );
		return openssl_decrypt( $cipher, 'aes-256-cbc', self::key(), OPENSSL_RAW_DATA, $iv );
	}
}
