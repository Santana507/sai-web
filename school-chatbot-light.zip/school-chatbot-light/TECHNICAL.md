# Arquitectura técnica — School Chatbot Light 3.0

## Cambio de integración

Anterior:

WordPress → Google OAuth / Drive API → Google Drive

Actual:

WordPress → POST HTTPS + secreto → Google Apps Script → Google Drive

WordPress gestiona la configuración, la extracción/indexación local y el chat. Apps Script autentica el secreto, conserva los IDs de las carpetas y ejecuta las operaciones Drive con la autorización de su propietario. Drive mantiene archivos y permisos. La burbuja pública nunca recibe la URL del Web App ni el secreto.

## Configuración y base de datos

La única opción global es wp_options.scl_options. Para Drive guarda apps_script_url, apps_script_secret cifrado, IDs y nombres de carpeta principal, Información Oficial y Documentos Importantes. Al actualizar a 3.0 se eliminan de esa opción los campos legacy de OAuth directo: google_client_id, google_client_secret, google_token y selección de carpeta anterior.

Las tablas existentes no cambian:

- {prefix}scl_documents: metadatos, texto extraído y estado de documentos oficiales.
- {prefix}scl_chunks: fragmentos usados en búsqueda léxica.

La sincronización lista el contenido de Información Oficial, compara modifiedTime, inserta o reindexa cambios y borra registros de archivos ya ausentes. Documentos Importantes se consultan bajo demanda por nombre; no se indexa su contenido.

## API interna Apps Script

Cada POST contiene operation y token; el script acepta solamente test_connection, create_structure, list_official_documents, list_important_documents y get_document_content. El secreto está en Script Properties de Apps Script y cifrado en WordPress. Un archivo solicitado para contenido debe ser hijo directo de Información Oficial.

Las respuestas incluyen IDs, nombre, MIME type, fecha de modificación, tamaño, URL real de Drive e indicador de acceso público. El script no cambia permisos. El chat únicamente muestra URLs de archivos que Drive marca como públicos/cualquiera con enlace.

## Limitaciones

El máximo de ejecución de Apps Script es seis minutos; las cuotas dependen de la cuenta, son por usuario y pueden cambiar. El código aplica un límite propio de 3 MB para el contenido devuelto a WordPress. No hay OCR, eventos en tiempo real ni procesamiento de archivos grandes. Si una cuota, permiso o tamaño falla, el archivo no se indexa y el error se devuelve al administrador.

Consulta ../google-apps-script/README.md para despliegue, autorización, pruebas y solución de errores.
