# School Chatbot Light 3.0

Chatbot WordPress con IA local o cloud y documentos de Google Drive mediante Google Apps Script.

## Instalación rápida

1. Activa el ZIP en WordPress y abre **Ajustes → School Chatbot Light**.
2. Configura IA LOCAL o NUBE, guarda y prueba la conexión.
3. Configura el proyecto de google-apps-script siguiendo su README.md.
4. Pega la URL /exec del Web App y el mismo secreto en WordPress; guarda y pulsa **Probar conexión con Apps Script**.
5. Pulsa **Crear estructura de carpetas**, sube archivos y usa **Sincronizar Google Drive**.

## Google Drive sin Cloud Console en WordPress

WordPress → HTTPS + secreto → Google Apps Script Web App → Google Drive

WordPress no almacena Client ID, Client Secret, contraseñas ni tokens OAuth de Google. La autorización de Drive se otorga una vez dentro del proyecto Apps Script, que se ejecuta bajo la cuenta administradora de Drive. El secreto compartido se cifra en wp_options y nunca se expone en el frontend.

El Web App crea y limita sus operaciones a Chatbot WordPress, Información Oficial y Documentos Importantes. No permite seleccionar ni descargar archivos de otras carpetas.

## Carpetas y sincronización

- **Información Oficial:** su contenido se extrae, fragmenta e indexa para las respuestas.
- **Documentos Importantes:** se consulta para entregar enlaces reales cuando el usuario los solicita; no se cambian permisos ni se inventan URLs.

La sincronización manual detecta archivos nuevos, modificados y eliminados en Información Oficial. DOCX requiere ZipArchive; PDF requiere pdftotext y texto seleccionable. PDFs escaneados necesitan OCR externo.

## IA

- **LOCAL:** Ollama o endpoint compatible, sin API Key cloud.
- **NUBE:** OpenAI, Gemini, Qwen, Google/Gemma, DeepSeek, Claude u Otro compatible.

Cambiar entre LOCAL y NUBE no afecta la conexión de Apps Script ni los documentos ya indexados.

## Límites importantes

Apps Script tiene un máximo oficial de seis minutos por ejecución y cuotas por usuario. El puente limita cada descarga a 3 MB antes de enviarla a WordPress. No hay sincronización en tiempo real. Consulta google-apps-script/README.md y TECHNICAL.md antes de producción.
